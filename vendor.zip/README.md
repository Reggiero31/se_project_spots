# Project 3: Spots

### Overview

- Intro
- Figma
- Images

**Intro**

This project is made so all the elements are displayed correctly on popular screen sizes. We recommend investing more time in completing this project, since it's more difficult than previous ones.

**Figma**

- [Link to the project on Figma](https://www.figma.com/file/BBNm2bC3lj8QQMHlnqRsga/Sprint-3-Project-%E2%80%94-Spots?type=design&node-id=2%3A60&mode=design&t=afgNFybdorZO6cQo-1)

**Images**

The way you'll do this at work is by exporting images directly from Figma — we recommend doing that to practice more. Don't forget to optimize them [here](https://tinypng.com/), so your project loads faster.

Good luck and have fun!

The project's name: Sprint 3 Spots

A description of the technologies and techniques used: Therefore I am using the Vs code to do my webpage project for sprint 3. However the techniques I used is to learned how to read the measurments when it come to creating a webpage and also when to know that you are using the right class for it.

Pictures, GIFs, or screenshots that detail the project features (highly recommended)
![alt text](image-1.png)

The link to your deployed project on GitHub Pages: https://github.com/Reggiero31/se_project_spots.git

![alt text](image-1.png)
